package com.qa.intellipaat.tests;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import utils.FileUtils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class SeleniumTest {

    private WebDriver driver;
    private String url;
    
    @BeforeMethod
	@BeforeClass
    public void setUp() {
        // Load configuration
        Properties prop = new Properties();
        try {
            prop.load(getClass().getClassLoader().getResourceAsStream("config/config.properties"));
            url = prop.getProperty("url");
        } catch (IOException e) {
            e.printStackTrace();
        }


        // Initialize ChromeDriver
        driver = new ChromeDriver();
    }

    @Test
    public void downloadPDF() {
        // Navigate to the webpage
        driver.get(url);

        // Find the link to download the PDF file
        WebElement pdfLink = driver.findElement(By.linkText("Download a Printable PDF of this Cheat Sheet"));

        // Get the URL of the PDF file
        String pdfUrl = pdfLink.getAttribute("href");

        // Specify the destination path to save the PDF file
        String destinationPath = "/Users/fuadkhan/Downloads/Selenium-Cheat-Sheet-2022.pdf";

        // Download the PDF file
        downloadFile(pdfUrl, destinationPath);
    }

    @AfterMethod
	@AfterClass
    public void tearDown() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    }

    // Method to download file from URL
    private void downloadFile(String fileUrl, String saveFilePath) {
        try {
            URL url = new URL(fileUrl);
            URLConnection conn = url.openConnection();
            conn.connect();

            try (InputStream in = conn.getInputStream();
                 FileOutputStream out = new FileOutputStream(saveFilePath)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
                System.out.println("File downloaded successfully.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("File download failed.");
        }
    }
}

